// server/utils/constants.js
module.exports = {
  ROLES: {
    ADMIN: 'admin',
    ASDOS: 'asdos',
    MHS: 'mahasiswa'
  }
};